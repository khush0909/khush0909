<div align="center">

# 📦 Brazilian E-commerce Analysis with SQL

**100K real orders from Olist, 8 related tables, 20 SQL queries — what drives growth, loyalty and bad reviews?**

![SQL](https://img.shields.io/badge/SQL-003B57?style=for-the-badge&logo=sqlite&logoColor=white)
![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)
![Pandas](https://img.shields.io/badge/Pandas-150458?style=for-the-badge&logo=pandas&logoColor=white)
![Jupyter](https://img.shields.io/badge/Jupyter-F37626?style=for-the-badge&logo=jupyter&logoColor=white)

</div>

<p align="center">
  <img src="images/02_reviews_by_delay.png" width="85%" alt="Share of bad reviews by delivery delay">
</p>

## 📌 Summary

Olist's monthly revenue grew about **7×** between January 2017 and August 2018. Using SQL on its public
database, I found three things that matter more than growth:

- 🚚 **Late delivery is the #1 cause of bad reviews.** On-time orders average 4.3★; orders 8+ days late average 1.7★, and 79% of them get 1–2 stars.
- 🔁 **Only 3% of customers ever come back.** The business runs almost entirely on first-time buyers.
- 🏪 **18% of sellers make 80% of revenue.** Keeping top sellers is worth more than adding new ones.

| Orders analysed | Revenue (R$) | Customers | Sellers | Avg delivery | Late deliveries |
|:---:|:---:|:---:|:---:|:---:|:---:|
| **98,199** | **13.5M** | **94,990** | **3,053** | **12.6 days** | **8.1%** |

## 📑 Contents
- [Dataset & schema](#-dataset--schema)
- [SQL skills shown](#-sql-skills-shown)
- [Data quality checks](#-data-quality-checks)
- [Key insights](#-key-insights)
- [Recommendations](#-recommendations)
- [Project structure](#-project-structure)
- [How to run](#-how-to-run)

## 🗂 Dataset & schema

[Olist Brazilian E-commerce public dataset](https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce) (real, anonymised orders, Sep 2016 – Oct 2018).
`scripts/build_database.py` downloads the CSVs from [Olist's official GitHub](https://github.com/olist/work-at-olist-data) and loads them into SQLite with keys and indexes.

```mermaid
erDiagram
    customers ||--o{ orders : places
    orders ||--|{ order_items : contains
    orders ||--o{ payments : "paid by"
    orders ||--o{ reviews : receives
    products ||--o{ order_items : "sold as"
    sellers ||--o{ order_items : fulfils
    category_translation ||--o{ products : names

    customers {
        text customer_id PK
        text customer_unique_id
        text customer_state
    }
    orders {
        text order_id PK
        text customer_id FK
        text order_status
        text order_purchase_timestamp
        text order_delivered_customer_date
        text order_estimated_delivery_date
    }
    order_items {
        text order_id FK
        int order_item_id
        text product_id FK
        text seller_id FK
        real price
        real freight_value
    }
    payments {
        text order_id FK
        text payment_type
        int payment_installments
        real payment_value
    }
    reviews {
        text review_id
        text order_id FK
        int review_score
    }
    products {
        text product_id PK
        text product_category_name
    }
    sellers {
        text seller_id PK
        text seller_state
    }
```

| Table | Rows | Table | Rows |
|-------|-----:|-------|-----:|
| orders | 99,441 | payments | 103,886 |
| order_items | 112,650 | reviews | 99,224 |
| customers | 99,441 | products | 32,951 |
| sellers | 3,095 | category_translation | 71 |

## 🛠 SQL skills shown

| Technique | Where |
|-----------|-------|
| Multi-table `JOIN`s (up to 4 tables), `LEFT JOIN` for missing lookups | [`04_products_and_sellers.sql`](sql/04_products_and_sellers.sql) |
| CTEs (`WITH`) chained 2–3 deep | every file |
| Window functions: `LAG`, `NTILE`, `ROW_NUMBER`, `RANK`, running `SUM() OVER` | [`01`](sql/01_sales_trends.sql), [`02`](sql/02_customers.sql), [`04`](sql/04_products_and_sellers.sql) |
| `PARTITION BY` (top seller per state) | [`04_products_and_sellers.sql`](sql/04_products_and_sellers.sql) |
| `CASE WHEN` bucketing and conditional aggregation | [`03_delivery_and_reviews.sql`](sql/03_delivery_and_reviews.sql) |
| Date maths (`julianday`, `strftime`) | [`03_delivery_and_reviews.sql`](sql/03_delivery_and_reviews.sql) |
| RFM customer segmentation | [`02_customers.sql`](sql/02_customers.sql) |
| Pareto / cumulative share analysis | [`04_products_and_sellers.sql`](sql/04_products_and_sellers.sql) |
| `UNION ALL`, `HAVING`, `COALESCE`, subqueries | [`00_data_quality.sql`](sql/00_data_quality.sql) |
| Indexes for join performance | [`build_database.py`](scripts/build_database.py) |

<details>
<summary><b>Example query — do late deliveries hurt reviews?</b></summary>

```sql
WITH delivery AS (
    SELECT order_id,
           julianday(date(order_delivered_customer_date))
             - julianday(date(order_estimated_delivery_date)) AS days_vs_promise
    FROM orders
    WHERE order_status = 'delivered'
      AND order_delivered_customer_date IS NOT NULL
),
review AS (
    SELECT order_id, AVG(review_score) AS score   -- some orders have 2+ reviews
    FROM reviews
    GROUP BY order_id
)
SELECT
    CASE WHEN d.days_vs_promise <= 0 THEN '1 On time or early'
         WHEN d.days_vs_promise <= 3 THEN '2 1–3 days late'
         WHEN d.days_vs_promise <= 7 THEN '3 4–7 days late'
         ELSE '4 8+ days late' END                                AS delivery_group,
    COUNT(*)                                                      AS orders,
    ROUND(AVG(r.score), 2)                                        AS avg_review,
    ROUND(100.0 * AVG(CASE WHEN r.score <= 2 THEN 1 ELSE 0 END), 1) AS pct_1_or_2_stars
FROM delivery d
JOIN review r ON r.order_id = d.order_id
GROUP BY delivery_group
ORDER BY delivery_group;
```

| delivery_group | orders | avg_review | pct_1_or_2_stars |
|---|---:|---:|---:|
| On time or early | 89,443 | 4.29 | 9.2 |
| 1–3 days late | 1,852 | 3.29 | 32.2 |
| 4–7 days late | 1,748 | 2.11 | 67.6 |
| 8+ days late | 2,781 | 1.70 | 79.2 |

</details>

## 🧹 Data quality checks

[`00_data_quality.sql`](sql/00_data_quality.sql) runs before any analysis. What it found and how each issue was handled:

| Check | Rows | Decision |
|-------|-----:|----------|
| 2016 and Sep–Oct 2018 have < 500 orders a month | — | Trends use Jan 2017 – Aug 2018 only |
| Canceled / unavailable orders | 1,234 | Excluded from revenue |
| Customers with several `customer_id`s | 2,997 | Count people with `customer_unique_id` |
| Orders with more than one review | 547 | Average the scores per order |
| Products with no category | 610 | Shown as `unknown`, not dropped |
| "Delivered" orders with no delivery date | 8 | Excluded from delivery-time queries |
| Column typos (`product_name_lenght`) | — | Renamed when building the database |

## 💡 Key insights

### 1. Revenue grew ~7× in 20 months, with a Black Friday spike
<img src="images/01_monthly_revenue.png" width="90%" alt="Monthly revenue">

Jan–Aug 2018 revenue (R$7.3M) was **2.4×** the same months of 2017. **24 Nov 2017 (Black Friday)** had 1,176 orders — more than double any other day.

### 2. Lateness drives bad reviews
On-time orders get 1–2 stars only 9% of the time. That jumps to **32%** at 1–3 days late and **79%** at 8+ days late.
Olist promises 23.7 days on average but delivers in 12.6 — yet 8.1% of orders still miss the promise.

### 3. Delivery time depends heavily on where the customer lives
<img src="images/03_delivery_by_state.png" width="75%" alt="Delivery days by state">

São Paulo customers wait 8.8 days; customers in Roraima wait **29.4 days (3.3×)**. Alagoas and Maranhão have late rates of 24% and 20%.

### 4. Almost nobody comes back — and big spenders are slipping away
<img src="images/05_customer_segments.png" width="90%" alt="RFM customer segments">

Just **3.0%** of 94,990 customers placed a second order. RFM scoring shows "big spenders at risk" (high spend, last order 10+ months ago)
are 15% of customers but **29% of revenue**.

### 5. Revenue is spread across categories but concentrated in sellers
<p>
  <img src="images/04_top_categories.png" width="49%" alt="Top categories">
  <img src="images/06_seller_pareto.png" width="49%" alt="Seller Pareto curve">
</p>

No category exceeds 10% of revenue, but **540 sellers (17.7%) generate 80% of it**. São Paulo customers alone are 38% of revenue.

### 6. Installments unlock bigger baskets
<img src="images/07_installments.png" width="70%" alt="Installments vs payment value">

Credit cards carry **78%** of payment value. Payments split into 7+ installments average R$334 — **3.5×** a pay-in-full payment.

## ✅ Recommendations

| # | Recommendation | Based on |
|---|----------------|----------|
| 1 | Flag orders likely to be late and send an apology + voucher **before** the customer reviews | 8+ days late → 79% bad reviews |
| 2 | Add sellers or a fulfilment partner in the north and north-east | 2–3× longer waits outside the south-east |
| 3 | Post-purchase email with a second-order discount within 60 days | 3% repeat rate |
| 4 | Win-back campaign for "big spenders at risk" first | 15% of customers, 29% of revenue |
| 5 | Account managers and faster payouts for the top ~540 sellers | 18% of sellers → 80% of revenue |
| 6 | Promote interest-free installments on high-price categories | 7+ installments = 3.5× basket size |

## 📁 Project structure

```
olist-ecommerce-sql-analysis/
├── scripts/
│   └── build_database.py        # downloads CSVs, builds data/olist.db with indexes
├── sql/
│   ├── 00_data_quality.sql
│   ├── 01_sales_trends.sql
│   ├── 02_customers.sql
│   ├── 03_delivery_and_reviews.sql
│   ├── 04_products_and_sellers.sql
│   └── 05_payments.sql
├── notebooks/
│   └── olist_sql_analysis.ipynb # runs every query, shows results, draws charts
├── results/                     # every query's output as CSV
├── images/                      # charts used in this README
├── data/raw/                    # CSVs (downloaded, not committed)
├── requirements.txt
└── README.md
```

## ▶️ How to run

```bash
git clone https://github.com/khush0909/olist-ecommerce-sql-analysis.git
cd olist-ecommerce-sql-analysis
pip install -r requirements.txt
python scripts/build_database.py          # ~1 minute, creates data/olist.db
jupyter notebook notebooks/olist_sql_analysis.ipynb
```

You can also open `data/olist.db` in [DB Browser for SQLite](https://sqlitebrowser.org/) or DBeaver and run any `.sql` file directly.

> **Using MySQL or PostgreSQL?** The queries are standard SQL except dates: replace `julianday(a) - julianday(b)` with
> `DATEDIFF(a, b)` (MySQL) or `a::date - b::date` (PostgreSQL), and `strftime('%Y-%m', x)` with `DATE_FORMAT(x, '%Y-%m')` / `TO_CHAR(x, 'YYYY-MM')`.

## 🧠 What I learned

- `customer_id` looked like a customer key but was really per-order — checking it changed the repeat rate from 0% to 3%.
- Window functions replace a lot of Python: running totals, rankings and month-over-month growth all stay in SQL.
- Indexes matter: the same join went from minutes to under a second after adding keys.

---

<div align="center">

**Khush Sahu** · Data Analyst · Gurugram

[GitHub](https://github.com/khush0909) · [LinkedIn](https://www.linkedin.com/in/khushsahu) · [Portfolio](https://khush0909.github.io)

</div>
