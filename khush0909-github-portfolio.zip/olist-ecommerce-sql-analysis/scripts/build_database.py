"""
Build the SQLite database used by every query in /sql.

    python scripts/build_database.py

1. Downloads the 8 Olist CSV files (from Olist's official GitHub repo) into data/raw/
   if they are not there yet.
2. Loads them into data/olist.db with short table names, primary keys and indexes.
"""
import sqlite3
import urllib.request
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
RAW = ROOT / "data" / "raw"
DB = ROOT / "data" / "olist.db"
SOURCE = "https://raw.githubusercontent.com/olist/work-at-olist-data/master/datasets/"

# csv file name -> table name in the database
FILES = {
    "olist_customers_dataset.csv": "customers",
    "olist_orders_dataset.csv": "orders",
    "olist_order_items_dataset.csv": "order_items",
    "olist_order_payments_dataset.csv": "payments",
    "olist_order_reviews_dataset.csv": "reviews",
    "olist_products_dataset.csv": "products",
    "olist_sellers_dataset.csv": "sellers",
    "product_category_name_translation.csv": "category_translation",
}

INDEXES = [
    # one row per key -> unique indexes act like primary keys and make joins fast
    "CREATE UNIQUE INDEX pk_customers ON customers(customer_id)",
    "CREATE UNIQUE INDEX pk_orders    ON orders(order_id)",
    "CREATE UNIQUE INDEX pk_products  ON products(product_id)",
    "CREATE UNIQUE INDEX pk_sellers   ON sellers(seller_id)",
    "CREATE UNIQUE INDEX pk_category  ON category_translation(product_category_name)",
    "CREATE INDEX idx_orders_customer  ON orders(customer_id)",
    "CREATE INDEX idx_orders_status    ON orders(order_status)",
    "CREATE INDEX idx_items_order      ON order_items(order_id)",
    "CREATE INDEX idx_items_product    ON order_items(product_id)",
    "CREATE INDEX idx_items_seller     ON order_items(seller_id)",
    "CREATE INDEX idx_payments_order   ON payments(order_id)",
    "CREATE INDEX idx_reviews_order    ON reviews(order_id)",
    "CREATE INDEX idx_customers_unique ON customers(customer_unique_id)",
]


def download_missing():
    RAW.mkdir(parents=True, exist_ok=True)
    for name in FILES:
        path = RAW / name
        if not path.exists():
            print(f"downloading {name} ...")
            urllib.request.urlretrieve(SOURCE + name, path)


def build():
    if DB.exists():
        DB.unlink()
    con = sqlite3.connect(DB)
    for name, table in FILES.items():
        df = pd.read_csv(RAW / name)
        # fix the original column-name typos ("lenght" -> "length")
        df.columns = [c.replace("lenght", "length") for c in df.columns]
        df.to_sql(table, con, index=False)
        print(f"{table:<22} {len(df):>8,} rows")
    for sql in INDEXES:
        con.execute(sql)
    con.commit()
    con.close()
    print(f"\nDatabase ready: {DB}")


if __name__ == "__main__":
    download_missing()
    build()
