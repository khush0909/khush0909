/* =====================================================================
   01 — Sales trends
   Revenue = item price (excluding freight) on orders that were NOT
   canceled or unavailable. Analysis window: Jan 2017 – Aug 2018
   (the only months with complete data). Currency: Brazilian real (R$).
   ===================================================================== */


-- name: monthly_revenue
-- How did orders, revenue and average order value change each month?
WITH order_revenue AS (
    SELECT order_id, SUM(price) AS revenue
    FROM order_items
    GROUP BY order_id
),
monthly AS (
    SELECT
        strftime('%Y-%m', o.order_purchase_timestamp) AS month,
        COUNT(*)                                       AS orders,
        ROUND(SUM(r.revenue), 0)                       AS revenue,
        ROUND(AVG(r.revenue), 2)                       AS avg_order_value
    FROM orders o
    JOIN order_revenue r ON r.order_id = o.order_id
    WHERE o.order_status NOT IN ('canceled', 'unavailable')
      AND o.order_purchase_timestamp >= '2017-01-01'
      AND o.order_purchase_timestamp <  '2018-09-01'
    GROUP BY month
)
SELECT
    month,
    orders,
    revenue,
    avg_order_value,
    ROUND(100.0 * (revenue - LAG(revenue) OVER (ORDER BY month))
                / LAG(revenue) OVER (ORDER BY month), 1) AS revenue_growth_pct
FROM monthly
ORDER BY month;


-- name: year_over_year
-- Same months, two years: Jan–Aug 2017 vs Jan–Aug 2018
WITH order_revenue AS (
    SELECT order_id, SUM(price) AS revenue
    FROM order_items
    GROUP BY order_id
)
SELECT
    strftime('%Y', o.order_purchase_timestamp) AS year,
    COUNT(*)                                   AS orders,
    ROUND(SUM(r.revenue), 0)                   AS revenue
FROM orders o
JOIN order_revenue r ON r.order_id = o.order_id
WHERE o.order_status NOT IN ('canceled', 'unavailable')
  AND strftime('%m', o.order_purchase_timestamp) BETWEEN '01' AND '08'
  AND strftime('%Y', o.order_purchase_timestamp) IN ('2017', '2018')
GROUP BY year;


-- name: busiest_days
-- Which single days had the most orders?
SELECT
    date(order_purchase_timestamp)                  AS order_date,
    CASE strftime('%w', order_purchase_timestamp)
        WHEN '0' THEN 'Sunday'   WHEN '1' THEN 'Monday'
        WHEN '2' THEN 'Tuesday'  WHEN '3' THEN 'Wednesday'
        WHEN '4' THEN 'Thursday' WHEN '5' THEN 'Friday'
        ELSE 'Saturday' END                         AS weekday,
    COUNT(*)                                        AS orders
FROM orders
GROUP BY order_date
ORDER BY orders DESC
LIMIT 5;


-- name: orders_by_weekday
-- Which weekdays are busiest?
SELECT
    CASE strftime('%w', order_purchase_timestamp)
        WHEN '0' THEN 'Sun' WHEN '1' THEN 'Mon' WHEN '2' THEN 'Tue'
        WHEN '3' THEN 'Wed' WHEN '4' THEN 'Thu' WHEN '5' THEN 'Fri'
        ELSE 'Sat' END                                   AS weekday,
    COUNT(*)                                             AS orders,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 1)   AS pct_of_orders
FROM orders
GROUP BY strftime('%w', order_purchase_timestamp)
ORDER BY strftime('%w', order_purchase_timestamp);
