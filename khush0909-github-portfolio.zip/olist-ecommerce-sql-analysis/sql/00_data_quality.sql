/* =====================================================================
   00 — Data quality checks
   Run these first: they tell us which rows to trust and which to filter.
   Dialect: SQLite (see README for MySQL / PostgreSQL notes)
   ===================================================================== */


-- name: row_counts
-- How big is each table?
SELECT 'customers'   AS table_name, COUNT(*) AS rows FROM customers
UNION ALL SELECT 'orders',      COUNT(*) FROM orders
UNION ALL SELECT 'order_items', COUNT(*) FROM order_items
UNION ALL SELECT 'payments',    COUNT(*) FROM payments
UNION ALL SELECT 'reviews',     COUNT(*) FROM reviews
UNION ALL SELECT 'products',    COUNT(*) FROM products
UNION ALL SELECT 'sellers',     COUNT(*) FROM sellers;


-- name: order_status
-- What share of orders were actually completed?
SELECT
    order_status,
    COUNT(*)                                            AS orders,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2)  AS pct_of_orders
FROM orders
GROUP BY order_status
ORDER BY orders DESC;


-- name: date_coverage
-- Which months have enough data to analyse? (2016 and Sep–Oct 2018 are almost empty)
SELECT
    strftime('%Y-%m', order_purchase_timestamp) AS month,
    COUNT(*)                                     AS orders
FROM orders
GROUP BY month
HAVING COUNT(*) < 500
ORDER BY month;


-- name: quality_issues
-- Known problems to handle in later queries
SELECT 'Orders with more than one review' AS check_name,
       COUNT(*) AS rows_affected
FROM (SELECT order_id FROM reviews GROUP BY order_id HAVING COUNT(*) > 1)

UNION ALL
SELECT 'Products with no category',
       COUNT(*)
FROM products
WHERE product_category_name IS NULL

UNION ALL
SELECT 'Categories with no English name',
       COUNT(DISTINCT p.product_category_name)
FROM products p
LEFT JOIN category_translation t ON t.product_category_name = p.product_category_name
WHERE p.product_category_name IS NOT NULL
  AND t.product_category_name_english IS NULL

UNION ALL
SELECT 'Delivered orders with no delivery date',
       COUNT(*)
FROM orders
WHERE order_status = 'delivered'
  AND order_delivered_customer_date IS NULL

UNION ALL
SELECT 'Customers with more than one customer_id',
       COUNT(*)
FROM (SELECT customer_unique_id FROM customers
      GROUP BY customer_unique_id HAVING COUNT(*) > 1);
