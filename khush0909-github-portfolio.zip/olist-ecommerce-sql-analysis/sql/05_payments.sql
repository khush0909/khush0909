/* =====================================================================
   05 — Payments
   ===================================================================== */


-- name: payment_mix
-- How do customers pay?
SELECT
    payment_type,
    COUNT(DISTINCT order_id)                                                  AS orders,
    ROUND(SUM(payment_value), 0)                                              AS total_paid,
    ROUND(100.0 * SUM(payment_value) / SUM(SUM(payment_value)) OVER (), 1)    AS pct_of_value,
    ROUND(AVG(payment_value), 2)                                              AS avg_payment
FROM payments
WHERE payment_type <> 'not_defined'
GROUP BY payment_type
ORDER BY total_paid DESC;


-- name: installments
-- Do customers split bigger purchases into more installments? (credit card only)
SELECT
    CASE
        WHEN payment_installments <= 1 THEN '1 (pay in full)'
        WHEN payment_installments <= 3 THEN '2–3'
        WHEN payment_installments <= 6 THEN '4–6'
        ELSE                                '7+'
    END                                                AS installments,
    COUNT(*)                                           AS payments,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS pct_of_payments,
    ROUND(AVG(payment_value), 2)                       AS avg_payment_value
FROM payments
WHERE payment_type = 'credit_card'
GROUP BY installments
ORDER BY installments;
