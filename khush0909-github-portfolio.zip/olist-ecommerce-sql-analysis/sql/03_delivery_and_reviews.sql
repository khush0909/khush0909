/* =====================================================================
   03 — Delivery performance and customer reviews
   Uses delivered orders that have a real delivery date.
   julianday(a) - julianday(b) = difference in days.
   ===================================================================== */


-- name: delivery_overview
-- How fast are deliveries, and how often are they late?
SELECT
    COUNT(*)                                                                    AS delivered_orders,
    ROUND(AVG(julianday(order_delivered_customer_date)
            - julianday(order_purchase_timestamp)), 1)                          AS avg_delivery_days,
    ROUND(AVG(julianday(order_estimated_delivery_date)
            - julianday(order_purchase_timestamp)), 1)                          AS avg_promised_days,
    ROUND(100.0 * AVG(CASE WHEN order_delivered_customer_date
                              > order_estimated_delivery_date THEN 1 ELSE 0 END), 1) AS pct_late
FROM orders
WHERE order_status = 'delivered'
  AND order_delivered_customer_date IS NOT NULL;


-- name: reviews_by_delay
-- Do late deliveries hurt review scores?
WITH delivery AS (
    SELECT
        order_id,
        julianday(date(order_delivered_customer_date))
          - julianday(date(order_estimated_delivery_date)) AS days_vs_promise
    FROM orders
    WHERE order_status = 'delivered'
      AND order_delivered_customer_date IS NOT NULL
),
review AS (
    -- a few orders have 2+ reviews: average them so each order counts once
    SELECT order_id, AVG(review_score) AS score
    FROM reviews
    GROUP BY order_id
)
SELECT
    CASE
        WHEN d.days_vs_promise <= 0  THEN '1 On time or early'
        WHEN d.days_vs_promise <= 3  THEN '2 1–3 days late'
        WHEN d.days_vs_promise <= 7  THEN '3 4–7 days late'
        ELSE                              '4 8+ days late'
    END                                                         AS delivery_group,
    COUNT(*)                                                    AS orders,
    ROUND(AVG(r.score), 2)                                      AS avg_review,
    ROUND(100.0 * AVG(CASE WHEN r.score <= 2 THEN 1 ELSE 0 END), 1) AS pct_1_or_2_stars
FROM delivery d
JOIN review r ON r.order_id = d.order_id
GROUP BY delivery_group
ORDER BY delivery_group;


-- name: delivery_by_state
-- Which customer states wait longest?
SELECT
    c.customer_state                                                 AS state,
    COUNT(*)                                                         AS orders,
    ROUND(AVG(julianday(o.order_delivered_customer_date)
            - julianday(o.order_purchase_timestamp)), 1)             AS avg_delivery_days,
    ROUND(100.0 * AVG(CASE WHEN o.order_delivered_customer_date
                              > o.order_estimated_delivery_date THEN 1 ELSE 0 END), 1) AS pct_late
FROM orders o
JOIN customers c ON c.customer_id = o.customer_id
WHERE o.order_status = 'delivered'
  AND o.order_delivered_customer_date IS NOT NULL
GROUP BY c.customer_state
ORDER BY avg_delivery_days;


-- name: review_distribution
-- What does the overall review mix look like?
SELECT
    review_score,
    COUNT(*)                                            AS reviews,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 1)  AS pct
FROM reviews
GROUP BY review_score
ORDER BY review_score;
