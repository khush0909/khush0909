/* =====================================================================
   02 — Customers
   Note: customer_id is created per ORDER. The real person is
   customer_unique_id, so always count customers with that column.
   ===================================================================== */


-- name: repeat_customers
-- How many customers come back for a second order?
WITH orders_per_customer AS (
    SELECT
        c.customer_unique_id,
        COUNT(DISTINCT o.order_id) AS orders
    FROM orders o
    JOIN customers c ON c.customer_id = o.customer_id
    WHERE o.order_status NOT IN ('canceled', 'unavailable')
    GROUP BY c.customer_unique_id
)
SELECT
    COUNT(*)                                        AS customers,
    SUM(CASE WHEN orders > 1 THEN 1 ELSE 0 END)     AS repeat_customers,
    ROUND(100.0 * SUM(CASE WHEN orders > 1 THEN 1 ELSE 0 END) / COUNT(*), 2) AS repeat_rate_pct,
    MAX(orders)                                     AS most_orders_by_one_customer
FROM orders_per_customer;


-- name: revenue_by_state
-- Where do customers live, and how concentrated is revenue? (top 10 states)
WITH state_revenue AS (
    SELECT
        c.customer_state                    AS state,
        COUNT(DISTINCT c.customer_unique_id) AS customers,
        ROUND(SUM(i.price), 0)              AS revenue
    FROM orders o
    JOIN customers   c ON c.customer_id = o.customer_id
    JOIN order_items i ON i.order_id    = o.order_id
    WHERE o.order_status NOT IN ('canceled', 'unavailable')
    GROUP BY c.customer_state
)
SELECT
    state,
    customers,
    revenue,
    ROUND(100.0 * revenue / SUM(revenue) OVER (), 1)                         AS pct_of_revenue,
    ROUND(100.0 * SUM(revenue) OVER (ORDER BY revenue DESC) / SUM(revenue) OVER (), 1) AS cumulative_pct
FROM state_revenue
ORDER BY revenue DESC
LIMIT 10;


-- name: rfm_segments
-- Segment customers by Recency (days since last order) and Monetary value.
-- 97% of customers order once, so Frequency is used as a simple repeat flag.
WITH customer_stats AS (
    SELECT
        c.customer_unique_id,
        MAX(o.order_purchase_timestamp) AS last_order,
        COUNT(DISTINCT o.order_id)      AS frequency,
        SUM(i.price)                    AS monetary
    FROM orders o
    JOIN customers   c ON c.customer_id = o.customer_id
    JOIN order_items i ON i.order_id    = o.order_id
    WHERE o.order_status NOT IN ('canceled', 'unavailable')
    GROUP BY c.customer_unique_id
),
scored AS (
    SELECT
        customer_unique_id,
        frequency,
        monetary,
        CAST(julianday((SELECT MAX(order_purchase_timestamp) FROM orders))
             - julianday(last_order) AS INTEGER)            AS recency_days,
        NTILE(5) OVER (ORDER BY last_order)                 AS r_score,   -- 5 = most recent
        NTILE(5) OVER (ORDER BY monetary)                   AS m_score    -- 5 = highest spend
    FROM customer_stats
),
segmented AS (
    SELECT *,
        CASE
            WHEN frequency > 1 AND m_score >= 4            THEN '1 Champions'
            WHEN frequency > 1                             THEN '2 Loyal'
            WHEN r_score >= 4 AND m_score >= 4             THEN '3 New big spenders'
            WHEN r_score >= 4                              THEN '4 New customers'
            WHEN r_score <= 2 AND m_score >= 4             THEN '5 Big spenders at risk'
            WHEN r_score <= 2                              THEN '7 Lost'
            ELSE                                                '6 Needs attention'
        END AS segment
    FROM scored
)
SELECT
    segment,
    COUNT(*)                                            AS customers,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 1)  AS pct_of_customers,
    ROUND(AVG(recency_days), 0)                         AS avg_recency_days,
    ROUND(AVG(monetary), 0)                             AS avg_spend,
    ROUND(SUM(monetary), 0)                             AS total_spend
FROM segmented
GROUP BY segment
ORDER BY segment;
