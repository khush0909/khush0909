/* =====================================================================
   04 — Products and sellers
   ===================================================================== */


-- name: top_categories
-- Which product categories bring in the most revenue?
SELECT
    COALESCE(t.product_category_name_english,
             p.product_category_name, 'unknown')   AS category,
    COUNT(DISTINCT i.order_id)                     AS orders,
    ROUND(SUM(i.price), 0)                         AS revenue,
    ROUND(AVG(i.price), 2)                         AS avg_item_price
FROM order_items i
JOIN orders   o ON o.order_id   = i.order_id
JOIN products p ON p.product_id = i.product_id
LEFT JOIN category_translation t ON t.product_category_name = p.product_category_name
WHERE o.order_status NOT IN ('canceled', 'unavailable')
GROUP BY category
ORDER BY revenue DESC
LIMIT 10;


-- name: worst_rated_categories
-- Among categories with 500+ reviewed orders, which ones have the lowest ratings?
WITH order_category AS (
    -- one category per order (the first item), to avoid counting an order twice
    SELECT i.order_id,
           COALESCE(t.product_category_name_english, p.product_category_name, 'unknown') AS category
    FROM order_items i
    JOIN products p ON p.product_id = i.product_id
    LEFT JOIN category_translation t ON t.product_category_name = p.product_category_name
    WHERE i.order_item_id = 1
),
order_review AS (
    SELECT order_id, AVG(review_score) AS score
    FROM reviews
    GROUP BY order_id
)
SELECT
    oc.category,
    COUNT(*)                                                       AS reviewed_orders,
    ROUND(AVG(r.score), 2)                                         AS avg_review,
    ROUND(100.0 * AVG(CASE WHEN r.score <= 2 THEN 1 ELSE 0 END), 1) AS pct_1_or_2_stars
FROM order_category oc
JOIN order_review r ON r.order_id = oc.order_id
GROUP BY oc.category
HAVING COUNT(*) >= 500
ORDER BY avg_review
LIMIT 8;


-- name: seller_concentration
-- What share of sellers generates 80% of revenue? (Pareto check)
WITH seller_revenue AS (
    SELECT i.seller_id, SUM(i.price) AS revenue
    FROM order_items i
    JOIN orders o ON o.order_id = i.order_id
    WHERE o.order_status NOT IN ('canceled', 'unavailable')
    GROUP BY i.seller_id
),
ranked AS (
    SELECT
        seller_id,
        revenue,
        ROW_NUMBER() OVER (ORDER BY revenue DESC)                     AS seller_rank,
        COUNT(*)     OVER ()                                          AS total_sellers,
        SUM(revenue) OVER (ORDER BY revenue DESC
                           ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)
                     / SUM(revenue) OVER ()                           AS cumulative_share
    FROM seller_revenue
)
SELECT
    MAX(total_sellers)                                             AS total_sellers,
    MIN(CASE WHEN cumulative_share >= 0.8 THEN seller_rank END)    AS sellers_for_80pct_revenue,
    ROUND(100.0 * MIN(CASE WHEN cumulative_share >= 0.8 THEN seller_rank END)
                / MAX(total_sellers), 1)                           AS pct_of_sellers
FROM ranked;


-- name: seller_pareto_curve
-- The full curve behind the Pareto check (used for the chart)
WITH seller_revenue AS (
    SELECT i.seller_id, SUM(i.price) AS revenue
    FROM order_items i
    JOIN orders o ON o.order_id = i.order_id
    WHERE o.order_status NOT IN ('canceled', 'unavailable')
    GROUP BY i.seller_id
)
SELECT
    ROUND(100.0 * ROW_NUMBER() OVER (ORDER BY revenue DESC) / COUNT(*) OVER (), 2) AS pct_of_sellers,
    ROUND(100.0 * SUM(revenue) OVER (ORDER BY revenue DESC
                                     ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)
                / SUM(revenue) OVER (), 2)                                      AS pct_of_revenue
FROM seller_revenue
ORDER BY pct_of_sellers;


-- name: top_seller_per_state
-- Who is the #1 seller in each of the 5 biggest seller states?
WITH seller_revenue AS (
    SELECT s.seller_state, i.seller_id, ROUND(SUM(i.price), 0) AS revenue,
           COUNT(DISTINCT i.order_id) AS orders
    FROM order_items i
    JOIN orders  o ON o.order_id  = i.order_id
    JOIN sellers s ON s.seller_id = i.seller_id
    WHERE o.order_status NOT IN ('canceled', 'unavailable')
    GROUP BY s.seller_state, i.seller_id
),
ranked AS (
    SELECT *,
           RANK() OVER (PARTITION BY seller_state ORDER BY revenue DESC) AS rank_in_state,
           SUM(revenue) OVER (PARTITION BY seller_state)                 AS state_revenue
    FROM seller_revenue
)
SELECT
    seller_state,
    substr(seller_id, 1, 8) || '…'                AS seller,
    orders,
    revenue,
    ROUND(100.0 * revenue / state_revenue, 1)     AS pct_of_state_revenue
FROM ranked
WHERE rank_in_state = 1
ORDER BY state_revenue DESC
LIMIT 5;
