# Tableau Dashboard — Build Guide

Build an interactive HR attrition dashboard in **Tableau Public** (free, Windows/Mac) and publish it online,
so recruiters can click through it from the main README.

Estimated build time: **1.5–2 hours**.

## 1. Connect

1. Download Tableau Public: <https://public.tableau.com/app/discover>
2. **Connect → Text file** → `../data/processed/hr_attrition_clean.csv` (created by the notebook — it already has the readable labels, age/tenure/income bands and the `RiskFactors` column).
3. On the Data Source tab, check `EmployeeNumber`, `JobLevel` and `RiskFactors` are **Dimensions** (blue) — right-click → *Convert to Dimension* if not.

## 2. Calculated fields

Right-click in the Data pane → **Create Calculated Field**:

| Name | Formula |
|------|---------|
| `Headcount` | `COUNTD([EmployeeNumber])` |
| `Leavers` | `SUM([Left])` |
| `Attrition Rate` | `SUM([Left]) / COUNTD([EmployeeNumber])` → format as Percentage, 1 decimal |
| `Avg Monthly Income` | `AVG([MonthlyIncome])` |
| `Risk Level` | `IF [RiskFactors] >= 3 THEN "High" ELSEIF [RiskFactors] = 2 THEN "Medium" ELSE "Low" END` |
| `Still Employed` | `[Attrition] = "No"` |

## 3. Sheets

| Sheet | Columns | Rows | Marks / colour |
|-------|---------|------|----------------|
| **KPI – Headcount / Leavers / Rate** | — | — | Text marks; one sheet per number, font size 28 |
| **By Department** | `Attrition Rate` | `Department` | Bar, sorted descending |
| **By Job Role** | `Attrition Rate` | `JobRole` | Bar, sorted; colour = `Attrition Rate` (sequential red) |
| **Overtime × Job Level** | `JobLevel` | `OverTime` | Square marks, colour = `Attrition Rate`, label = `Attrition Rate` (heatmap) |
| **Tenure** | `TenureBand` | `Attrition Rate` | Bar |
| **Age** | `AgeBand` | `Attrition Rate` | Bar |
| **Risk Factors** | `RiskFactors` | `Attrition Rate` | Bar; add `Headcount` to Tooltip |
| **At-Risk Employees** | — | `EmployeeNumber`, `Department`, `JobRole`, `RiskFactors` | Text table; filter `Still Employed = True` and `Risk Level = High`; sort by `RiskFactors` desc |

Colours: use `#2A78D6` (blue) for normal bars and `#E34948` (red) for the highlighted/high-risk group, to match the notebook charts.

## 4. Dashboard

**Dashboard → New** → size **Automatic** (or 1200 × 900):

```
┌───────────────────────────────────────────────────────────────┐
│ Employee Attrition Dashboard         [Department ▾] [Gender ▾]│
├──────────────┬──────────────┬──────────────┬──────────────────┤
│  Headcount   │   Leavers    │ Attrition %  │  At-risk staff   │
├──────────────┴──────────────┼──────────────┴──────────────────┤
│ Attrition by Job Role       │ Overtime × Job Level heatmap    │
├──────────────┬──────────────┼─────────────────────────────────┤
│ Tenure       │ Age          │ Risk factors                    │
├──────────────┴──────────────┴─────────────────────────────────┤
│ At-risk employee list (current staff with 3+ risk factors)    │
└───────────────────────────────────────────────────────────────┘
```

- Add `Department` and `Gender` as filters → right-click each → **Apply to Worksheets → All Using This Data Source**.
- Click **By Job Role** → **Use as Filter** (funnel icon), so clicking a role filters the whole dashboard.

## 5. Publish

1. **File → Save to Tableau Public As…** → sign in (free account) → name it *Employee Attrition Dashboard*.
2. The dashboard opens in your browser. Copy its URL.
3. Take a screenshot → save as `../images/tableau_dashboard.png`.
4. In the main `README.md`, replace `YOUR-TABLEAU-LINK` with the URL and remove the `<!--` / `-->` around the screenshot.
5. Also add the link to your portfolio website.
