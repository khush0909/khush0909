<div align="center">

# 👥 Employee Attrition Analysis

**Why are 1 in 6 employees leaving — and who is likely to leave next?**

![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)
![Pandas](https://img.shields.io/badge/Pandas-150458?style=for-the-badge&logo=pandas&logoColor=white)
![Matplotlib](https://img.shields.io/badge/Matplotlib-11557C?style=for-the-badge)
![Tableau](https://img.shields.io/badge/Tableau-E97627?style=for-the-badge&logo=tableau&logoColor=white)

</div>

<p align="center">
  <img src="images/01_attrition_drivers.png" width="85%" alt="Attrition drivers">
</p>

## 📌 Summary

The company lost **237 of 1,470 employees (16.1%)**. I analysed 35 HR attributes and found that leaving is
driven mostly by **overtime, being new or junior, and low pay** — and that these risks stack up:
employees with 5–6 risk factors leave at **72%**, versus **5%** for those with none.
I then flagged **208 current employees** who match 3+ risk factors so HR can act before they resign.

| Employees | Left | Attrition rate | Overtime vs no overtime | Current staff at high risk |
|:---:|:---:|:---:|:---:|:---:|
| **1,470** | **237** | **16.1%** | **30.5% vs 10.4%** | **208** |

## 📑 Contents
- [Business problem](#-business-problem)
- [Dataset](#-dataset)
- [Data preparation](#-data-preparation)
- [Key insights](#-key-insights)
- [Who is at risk now?](#-who-is-at-risk-now)
- [Recommendations](#-recommendations)
- [Tableau dashboard](#-tableau-dashboard)
- [Project structure](#-project-structure)

## 🎯 Business problem

Every resignation costs hiring, training and lost productivity. HR asked:
1. Which departments, roles, ages and pay levels lose the most people?
2. Which work conditions — overtime, travel, satisfaction — are linked to leaving?
3. How many **current** employees look like the ones who left?
4. Where should HR focus first?

## 🗂 Dataset

[IBM HR Analytics Employee Attrition dataset](https://github.com/IBM/employee-attrition-aif360) — 1,470 employees × 35 columns
(demographics, job role and level, pay, overtime, travel, tenure, satisfaction surveys, and whether they left).

> ℹ️ This is a fictional dataset created by IBM data scientists for practice. The patterns are realistic, but it does not describe a real company.

## 🧹 Data preparation

| Step | Detail |
|------|--------|
| Quality checks | 0 missing values, 0 duplicates, `EmployeeNumber` unique |
| Dropped 3 useless columns | `EmployeeCount`, `Over18`, `StandardHours` have one value for everyone |
| Decoded survey scores | e.g. `JobSatisfaction` 1–4 → Low / Medium / High / Very High; `Education` 1–5 → Below College … Doctor |
| Created bands | Age (18–25 …), tenure (≤1 yr …), income quartiles |
| Created `Left` flag (1/0) | So the average of `Left` is directly the attrition rate |
| Created `RiskFactors` | Count of 6 risk conditions per employee (see below) |

Output: [`data/processed/hr_attrition_clean.csv`](data/processed/hr_attrition_clean.csv) (also feeds the Tableau dashboard).

## 💡 Key insights

### 1. Overtime is the biggest single driver
**30.5%** of employees who work overtime left, vs **10.4%** of those who don't — nearly **3×**.
Overtime workers are 28% of staff but 54% of leavers.

### 2. Overtime hits entry-level staff hardest
<img src="images/02_overtime_by_level.png" width="85%" alt="Overtime by job level">

At job level 1, **53%** of overtime workers left. At 4 of the 5 job levels, overtime more than doubles attrition.

### 3. Sales Representatives and Lab Technicians churn the most
<img src="images/03_job_roles.png" width="80%" alt="Attrition by job role">

**4 in 10** Sales Representatives left. Research Directors and Managers barely leave (2–5%).

### 4. New, young and low-paid employees leave at about 1 in 3
<img src="images/04_tenure_age_income.png" width="95%" alt="Tenure, age and income">

- **35%** of employees in their first year left (vs 8% after 10+ years)
- **36%** of employees aged 18–25 left
- **29%** of the lowest-paid quarter left — the top half is around 10%

### 5. Work-life balance matters more than other satisfaction scores
<img src="images/05_satisfaction.png" width="95%" alt="Satisfaction scores">

Employees rating work-life balance "Bad" left at **31%**, the highest of any satisfaction score.

## 🚨 Who is at risk now?

I counted how many of 6 risk conditions each employee has — **overtime, job level 1, age ≤ 25, first year,
lowest income quartile, no stock options**:

<img src="images/06_risk_factor_count.png" width="85%" alt="Attrition by number of risk factors">

Risk stacks up: attrition climbs from **5%** (no factors) to **26%** (3), **45%** (4) and **72%** (5–6).
Applying the same rule to people still employed gives **208 current employees (17%) with 3+ risk factors** —
saved as [`current_employees_at_risk.csv`](data/processed/current_employees_at_risk.csv) for managers to follow up.

## ✅ Recommendations

| # | Recommendation | Why |
|---|----------------|-----|
| 1 | **Cap regular overtime**, starting with Sales and the labs | Overtime ≈ 3× attrition; 53% at entry level |
| 2 | **Structured onboarding** — buddy, 30/60/90-day check-ins | 35% of first-year staff leave |
| 3 | **Review Sales Rep pay mix and career path** to Sales Executive | 40% attrition |
| 4 | **Benchmark entry-level pay; extend stock options** to levels 1–2 | Lowest-paid and no-stock staff leave ~2.5× more |
| 5 | **Stay interviews** with the 208 flagged employees this quarter | Their profile matches people who left |

## 📊 Tableau dashboard

Interactive dashboard (filters by department, gender and job role) — build steps in [`tableau/README.md`](tableau/README.md).

<!-- After publishing to Tableau Public, remove these comment markers and paste your link:
**[▶ Open the live dashboard](YOUR-TABLEAU-LINK)**
<img src="images/tableau_dashboard.png" width="100%" alt="Tableau dashboard">
-->

## 📁 Project structure

```
hr-attrition-analysis/
├── data/
│   ├── raw/hr_employee_attrition.csv
│   └── processed/
│       ├── hr_attrition_clean.csv          # cleaned + labelled (used by Tableau)
│       └── current_employees_at_risk.csv   # 208 flagged employees
├── notebooks/
│   └── hr_attrition_analysis.ipynb
├── tableau/
│   └── README.md                           # dashboard build guide
├── images/
├── requirements.txt
└── README.md
```

## ▶️ How to run

```bash
git clone https://github.com/khush0909/hr-attrition-analysis.git
cd hr-attrition-analysis
pip install -r requirements.txt
jupyter notebook notebooks/hr_attrition_analysis.ipynb
```

## 🧠 What I learned

- Comparing each "risk group" with *everyone else* gives a fairer picture than comparing with the company average.
- Single factors tell part of the story; combining them (overtime × job level) revealed the 53% hotspot.
- Turning analysis into a list of people to talk to makes it something HR can act on tomorrow.

---

<div align="center">

**Khush Sahu** · Data Analyst · Gurugram

[GitHub](https://github.com/khush0909) · [LinkedIn](https://www.linkedin.com/in/khushsahu) · [Portfolio](https://khush0909.github.io)

</div>
