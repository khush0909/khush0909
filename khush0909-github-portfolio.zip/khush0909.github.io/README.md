# khush0909.github.io

Source of my portfolio site: **https://khush0909.github.io**

A single static page (`index.html`) — no build step. The charts are drawn with plain JavaScript and SVG from the real
results of my three projects, follow the light/dark theme, and show details on hover or keyboard focus.

| Project | Repository |
|---------|------------|
| Superstore Sales & Profitability | [superstore-sales-analysis](https://github.com/khush0909/superstore-sales-analysis) |
| Brazilian E-commerce with SQL | [olist-ecommerce-sql-analysis](https://github.com/khush0909/olist-ecommerce-sql-analysis) |
| Employee Attrition Analysis | [hr-attrition-analysis](https://github.com/khush0909/hr-attrition-analysis) |

To update: edit `index.html`, add `resume.pdf` next to it, commit and push — GitHub Pages republishes in about a minute.
