<picture>
  <source media="(prefers-color-scheme: dark)" srcset="assets/banner-dark.png">
  <img src="assets/banner-light.png" alt="Khush Sahu — data analyst. SQL, Python, Power BI, Excel, Alteryx and Tableau." width="100%">
</picture>

### Hi, I'm Khush 👋

I'm a **data analyst** based in Gurugram. I've just finished my B.Tech in Computer Science at **Lovely Professional University**
and a six-month **Data Analyst Internship at KPMG**.

- 💼 **KPMG, Jan–Jul 2026:** SQL transaction reconciliation, Power BI client dashboards, Python and Excel-macro report automation, Alteryx data workflows
- 🔍 I clean messy data with **SQL and Python**, then turn it into **dashboards and recommendations** a manager can act on
- 🎯 Looking for **entry-level data analyst roles**
- 🌐 Portfolio: **[khush0909.github.io](https://khush0909.github.io)** · 📄 [Résumé](https://khush0909.github.io/resume.pdf)
- 📫 Reach me: [LinkedIn](https://www.linkedin.com/in/khushsahu) · [Email](mailto:sahukhush2005@gmail.com)

---

## 📊 Featured projects

<table>
<tr>
<td width="50%"><a href="https://github.com/khush0909/superstore-sales-analysis"><img src="assets/superstore.png" alt="Discount impact chart"></a></td>
<td>

### [🛒 Superstore Sales & Profitability](https://github.com/khush0909/superstore-sales-analysis)
**Where is a growing retailer losing profit?**
Sales grew 52%, but order lines discounted above 20% **lost $135K**. Cleaned 9,994 orders, found the leaks, built an interactive Excel dashboard.

`Python` `Pandas` `Excel` `Power BI`

</td>
</tr>
<tr>
<td width="50%"><a href="https://github.com/khush0909/olist-ecommerce-sql-analysis"><img src="assets/olist.png" alt="Late delivery vs bad reviews chart"></a></td>
<td>

### [📦 Brazilian E-commerce with SQL](https://github.com/khush0909/olist-ecommerce-sql-analysis)
**What drives growth, loyalty and bad reviews?**
20 SQL queries over 100K orders in 8 tables. Orders 8+ days late get **79% bad reviews**; only 3% of customers return.

`SQL` `SQLite` `Window functions` `Python`

</td>
</tr>
<tr>
<td width="50%"><a href="https://github.com/khush0909/hr-attrition-analysis"><img src="assets/hr.png" alt="Attrition by risk factors chart"></a></td>
<td>

### [👥 Employee Attrition Analysis](https://github.com/khush0909/hr-attrition-analysis)
**Why are 1 in 6 employees leaving, and who is next?**
Overtime nearly triples attrition. Built a risk score — 5–6 risk factors means **72% leave** — and flagged 208 current staff.

`Python` `Pandas` `Tableau`

</td>
</tr>
</table>

---

## 🧰 Toolbox

![Python](https://img.shields.io/badge/Python-3776AB?style=flat-square&logo=python&logoColor=white)
![Pandas](https://img.shields.io/badge/Pandas-150458?style=flat-square&logo=pandas&logoColor=white)
![NumPy](https://img.shields.io/badge/NumPy-013243?style=flat-square&logo=numpy&logoColor=white)
![Matplotlib](https://img.shields.io/badge/Matplotlib-11557C?style=flat-square)
![Seaborn](https://img.shields.io/badge/Seaborn-4C72B0?style=flat-square)
![Jupyter](https://img.shields.io/badge/Jupyter-F37626?style=flat-square&logo=jupyter&logoColor=white)
![SQL](https://img.shields.io/badge/SQL-003B57?style=flat-square&logo=sqlite&logoColor=white)
![Excel](https://img.shields.io/badge/Excel-217346?style=flat-square&logo=microsoftexcel&logoColor=white)
![Power BI](https://img.shields.io/badge/Power_BI-F2C811?style=flat-square&logo=powerbi&logoColor=black)
![Tableau](https://img.shields.io/badge/Tableau-E97627?style=flat-square&logo=tableau&logoColor=white)
![Alteryx](https://img.shields.io/badge/Alteryx-0078C0?style=flat-square)
![Power Automate](https://img.shields.io/badge/Power_Automate-0066FF?style=flat-square)
![Git](https://img.shields.io/badge/Git-F05032?style=flat-square&logo=git&logoColor=white)

| | What I've done with it |
|---|---|
| **SQL** | Transaction reconciliation at KPMG; CTEs, multi-table joins, window functions (`LAG`, `NTILE`, `RANK`), RFM segmentation |
| **Power BI** | Client dashboards and KPI reports at KPMG; Power Query, DAX measures, star-schema models |
| **Python** | Report automation at KPMG; cleaning and analysis with Pandas, charts with Matplotlib and Seaborn |
| **Excel** | Macros for recurring reports; `SUMIFS` dashboards, pivot tables, data validation |
| **Alteryx** | End-to-end data cleaning and transformation workflows at KPMG |
| **Tableau** | Interactive dashboards with calculated fields and filter actions |

---

<p align="center">
  <a href="https://khush0909.github.io"><b>Visit my portfolio</b></a> ·
  <a href="https://www.linkedin.com/in/khushsahu"><b>Connect on LinkedIn</b></a>
</p>
