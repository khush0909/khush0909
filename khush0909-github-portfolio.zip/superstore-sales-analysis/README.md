<div align="center">

# 🛒 Superstore Sales & Profitability Analysis

**Where is a growing retailer losing profit — and what should it change?**

![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)
![Pandas](https://img.shields.io/badge/Pandas-150458?style=for-the-badge&logo=pandas&logoColor=white)
![Matplotlib](https://img.shields.io/badge/Matplotlib-11557C?style=for-the-badge)
![Excel](https://img.shields.io/badge/Excel-217346?style=for-the-badge&logo=microsoftexcel&logoColor=white)
![Power BI](https://img.shields.io/badge/Power_BI-F2C811?style=for-the-badge&logo=powerbi&logoColor=black)

</div>

<p align="center">
  <img src="images/03_discount_impact.png" width="85%" alt="Profit margin by discount band">
</p>

## 📌 Summary

Superstore's sales grew **52%** from 2015 to 2018, but its profit margin stayed stuck at about **12.5%**.
I cleaned 9,994 order lines and found that **heavy discounting is the main profit leak**: the 14% of
order lines sold at more than 20% off lost **$135K**, while every other line earned **$422K**.

| Total sales | Total profit | Profit margin | Orders | Customers |
|:-----------:|:------------:|:-------------:|:------:|:---------:|
| **$2.30M** | **$286.4K** | **12.5%** | **5,009** | **793** |

## 📑 Contents
- [Business problem](#-business-problem)
- [Dataset](#-dataset)
- [Data cleaning](#-data-cleaning)
- [Key insights](#-key-insights)
- [Recommendations](#-recommendations)
- [Excel dashboard](#-excel-dashboard)
- [Power BI dashboard](#-power-bi-dashboard)
- [Project structure](#-project-structure)
- [How to run](#-how-to-run)

## 🎯 Business problem

Management sees revenue going up every year but profit not keeping pace. They asked:

1. How have sales, profit and margin moved year by year?
2. Which categories and sub-categories make or lose money?
3. How do discounts affect profit?
4. Which regions and states are under-performing, and why?
5. Is there seasonality to plan inventory and staff around?
6. Which regions have the highest return rate?

## 🗂 Dataset

[Tableau *Sample – Superstore*](https://public.tableau.com/app/learn/sample-data) — a widely used retail dataset.

| Table | Rows | Description |
|-------|-----:|-------------|
| `orders.csv` | 9,994 | One row per order line: dates, customer, product, sales, quantity, discount, profit |
| `people.csv` | 4 | Regional manager for each region |
| `returns.csv` | 800 | Returned items (296 unique orders) |

## 🧹 Data cleaning

Done in [`notebooks/superstore_analysis.ipynb`](notebooks/superstore_analysis.ipynb).

| Issue found | Fix |
|-------------|-----|
| Order and ship dates stored as text | Converted with `pd.to_datetime(format='%m/%d/%Y')` |
| 11 rows missing postal code (all Burlington, Vermont) | Filled with `05401` |
| Postal codes read as numbers, losing leading zeros (`5401`) | Stored as 5-character text with `zfill(5)` |
| 1 exact duplicate order line | Dropped |
| `returns` lists each returned *item*, so order IDs repeat | De-duplicated before joining |
| No time or discount groupings | Added `Year`, `Month`, `Ship Days`, `Profit Margin`, `Discount Band` |

Result: **9,993 clean rows**, joined with manager and returned-order flags → [`data/processed/superstore_clean.csv`](data/processed/superstore_clean.csv).

## 💡 Key insights

### 1. Sales are growing, but margin isn't
<img src="images/01_yearly_trend.png" width="90%" alt="Yearly sales and margin">

Sales went from $484K to $733K, but margin has hovered around 13% since 2016. Growth is coming from volume, not from more profitable selling.

### 2. Discounts above 20% destroy profit
Undiscounted lines earn a **30% margin**. At 21–40% off, margin is **−15%**; at 41–80% off, the company loses **77 cents on every dollar**.
Those heavily discounted lines are only 13.9% of all lines but wipe out about a third of the profit the rest of the business makes.

### 3. Furniture is a third of sales but only 6% of profit
<img src="images/02_subcategory_profit.png" width="80%" alt="Profit by sub-category">

**Tables (−$17.7K)**, **Bookcases (−$3.5K)** and **Supplies (−$1.2K)** lose money. Copiers, Phones and Accessories are the profit engines.

### 4. Central has the lowest margin — because it discounts the most
<img src="images/04_region_discounting.png" width="90%" alt="Region margin vs discounting">

27.7% of Central's order lines carry a discount above 20%, versus 3.7% in the West. Central's margin (7.9%) is about half the West's (14.9%).
10 states are loss-making; **Texas (−$25.7K)**, **Ohio**, **Pennsylvania** and **Illinois** are the worst — all with average discounts above 30%.

### 5. Q4 is peak season
<img src="images/05_monthly_seasonality.png" width="90%" alt="Monthly seasonality">

September, November and December together bring in **43%** of yearly sales; January and February are the quietest months.

### 6. The West has a returns problem
<img src="images/06_return_rate.png" width="80%" alt="Return rate by region">

5.9% of all orders have a return, but in the West it's **11.7%** — more than 3× any other region.

## ✅ Recommendations

| # | Recommendation | Why |
|---|----------------|-----|
| 1 | **Cap discounts at 20%** unless a manager approves | Lines above 20% lost $135K |
| 2 | **Re-price Tables and Bookcases**, or bundle them with profitable chairs and furnishings | Tables lost money in all 4 years; Bookcases in 3 of 4 |
| 3 | **Start the discount review in Central** (Texas, Illinois first) | Lowest margin, heaviest discounting |
| 4 | **Stock up and staff up before Q4**; run promotions in Jan–Feb | 43% of sales land in three months |
| 5 | **Audit the most-returned products in the West** | Return rate is 3×+ other regions |

## 📊 Excel dashboard

[`excel/Superstore_Sales_Dashboard.xlsx`](excel/Superstore_Sales_Dashboard.xlsx) — pick a year from the dropdown and every KPI and chart updates.

<img src="images/excel_dashboard.png" width="100%" alt="Excel dashboard">

- **10,000+ live formulas** — `SUMIFS` / `COUNTIFS` with a dynamic year range, `IFERROR`, no hard-coded numbers
- Year selector built with **data validation**
- Clean data stored as an **Excel Table** with filters
- Distinct order count with a fast helper column instead of a slow `COUNTIF` array

## 📈 Power BI dashboard

Data model (star schema), Power Query cleaning steps, 20 DAX measures and the report theme are in [`powerbi/`](powerbi/).

<!-- After building the report, remove these comment markers:
<img src="images/powerbi_overview.png" width="100%" alt="Power BI overview page">
<img src="images/powerbi_profitability.png" width="100%" alt="Power BI profitability page">
-->

**DAX used:** `CALCULATE`, `DIVIDE`, `DISTINCTCOUNT`, `SAMEPERIODLASTYEAR`, `TOTALYTD`, `AVERAGEX`, `DATEDIFF`, conditional-colour measures.

## 📁 Project structure

```
superstore-sales-analysis/
├── data/
│   ├── raw/                  # orders.csv, people.csv, returns.csv
│   └── processed/            # superstore_clean.csv (output of the notebook)
├── notebooks/
│   └── superstore_analysis.ipynb
├── excel/
│   └── Superstore_Sales_Dashboard.xlsx
├── powerbi/
│   ├── README.md             # step-by-step build guide
│   ├── measures.dax
│   └── superstore_theme.json
├── images/                   # charts used in this README
├── requirements.txt
└── README.md
```

## ▶️ How to run

```bash
git clone https://github.com/khush0909/superstore-sales-analysis.git
cd superstore-sales-analysis
pip install -r requirements.txt
jupyter notebook notebooks/superstore_analysis.ipynb
```

## 🧠 What I learned

- Profit and revenue can tell opposite stories — always look at margin, not just sales.
- Grouping a continuous column (discount) into bands made a clear, explainable pattern.
- A data-quality check *before* analysis caught a duplicate row and a ZIP-code bug that would have broken a map visual.

---

<div align="center">

**Khush Sahu** · Data Analyst · Gurugram

[GitHub](https://github.com/khush0909) · [LinkedIn](https://www.linkedin.com/in/khushsahu) · [Portfolio](https://khush0909.github.io)

</div>
