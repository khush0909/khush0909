# Power BI Dashboard — Build Guide

This folder has everything needed to build the Superstore dashboard in **Power BI Desktop** (free, Windows):

| File | What it is |
|------|------------|
| `measures.dax` | Calendar table + 20 DAX measures (copy-paste ready) |
| `superstore_theme.json` | Report theme so colours match the rest of the project |
| `Superstore_Dashboard.pbix` | *Add after building* — the finished report |

Estimated build time: **1.5–2 hours**.

---

## 1. Load the data (Power Query)

1. **Home → Get data → Text/CSV** → load `../data/raw/orders.csv`, `people.csv` and `returns.csv` → click **Transform Data**.
2. **`orders` query**
   - Select `Order Date` and `Ship Date` → right-click → **Change Type → Using Locale… → Date → English (United States)**.
     *(Needed because the file uses `m/d/yyyy`; with an Indian locale, Power BI would read 11/8/2017 as 11 August.)*
   - `Postal Code`: **Replace Values** `null` → `5401` (the 11 Burlington, VT rows), then **Add Column → Custom Column**:
     ```
     Text.PadStart(Text.From([Postal Code]), 5, "0")
     ```
     Name it `Postal Code (Text)`, delete the old column.
   - Select every column **except** `Row ID` → **Home → Remove Rows → Remove Duplicates** (removes 1 duplicate line).
   - **Add Column → Conditional Column** `Discount Band`:
     `Discount = 0 → "No discount"`, `<= 0.2 → "1–20%"`, `<= 0.4 → "21–40%"`, else `"41–80%"`.
3. **`returns` query** → select `Order ID` → **Remove Duplicates** (800 item rows → 296 orders).
4. **`orders` query → Home → Merge Queries** → join `returns` on `Order ID` (Left Outer) → expand only `Returned` → **Replace Values** `null` → `No`.
5. Right-click `returns` → untick **Enable load** (it's merged in now). Rename `orders` to **Orders**, `people` to **People**.
6. **Close & Apply**.

## 2. Model

1. **Modeling → New table** → paste the `Calendar` formula from `measures.dax`. Mark it as a date table.
2. **Model view** — create two relationships:

```
People[Region]  1 ──────── * Orders[Region]
Calendar[Date]  1 ──────── * Orders[Order Date]
```

3. **Home → Enter data** → create an empty table `_Measures` → add every measure from `measures.dax`.
4. Format measures: `Total Sales`, `Total Profit`, `Avg Order Value` → Currency, 0 decimals. `Profit Margin`, `Return Rate`, `Sales YoY %` → Percentage, 1 decimal.

## 3. Theme

**View → Themes → Browse for themes** → `superstore_theme.json`.

## 4. Report pages

### Page 1 — Overview
```
┌──────────────────────────────────────────────────────────────────┐
│ Superstore Sales Overview          [Year ▾] [Region ▾] [Segment ▾]│
├──────────┬──────────┬──────────┬──────────┬──────────┬───────────┤
│  Sales   │  Profit  │  Margin  │  Orders  │   AOV    │ Return %  │  ← Card visuals
├──────────┴──────────┴──────────┼──────────┴──────────┴───────────┤
│ Line: Total Sales by           │ Bar: Total Profit by Category   │
│ Calendar[Year-Month]           │                                 │
├────────────────────────────────┼─────────────────────────────────┤
│ Filled map: Profit by State    │ Bar: Sales by Segment           │
└────────────────────────────────┴─────────────────────────────────┘
```

### Page 2 — Profitability
- **Bar chart:** `Total Profit` by `Sub-Category`, sorted ascending, bar colour → *fx → Field value → Profit Colour*.
- **Column chart:** `Profit Margin` by `Discount Band`.
- **Scatter chart:** X = `Avg Discount`, Y = `Profit Margin`, Details = `Sub-Category`, Size = `Total Sales`.
- **Card:** `Heavy Discount Profit` (shows the ~-$135K lost on >20% discounts).

### Page 3 — Regions & Returns
- **Table:** Region, Manager, `Total Sales`, `Profit Margin`, `Heavy Discount Share`, `Return Rate` (add data bars to `Return Rate`).
- **Bar chart:** `Total Profit` by `State` — Top N filter: bottom 10.
- **Column chart:** `Avg Ship Days` by `Ship Mode`.

**Slicers** (Year, Region, Segment) go on every page: **View → Sync slicers**.

## 5. Finish

1. Save as `Superstore_Dashboard.pbix` in this folder.
2. Take a screenshot of each page (Windows: `Win + Shift + S`) → save as
   `../images/powerbi_overview.png`, `../images/powerbi_profitability.png`.
3. Open the main `README.md`, find the **Power BI dashboard** section and remove the `<!--` and `-->` around the image lines.
4. Commit and push.
